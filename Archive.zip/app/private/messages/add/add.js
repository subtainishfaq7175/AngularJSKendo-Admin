/**
 * Created by subtainishfaq on 10/30/16.
 */
angular.module('yapp')
  .controller('MessageAddCtrl', function($scope, $state) {

    $scope.$state = $state;
    $scope.html;

  });
